# snake-clojure

### A Clojure project based on [Stuart Halloway’s Snake](https://github.com/stuarthalloway/programming-clojure).

Namespace is examples.snake and the core.clj file that Leiningen created has been renamed app.clj.

That file imports libraries from java.awt, javax.swing, and java.awt.event. Playing with the logic in a functional form.

Note-taking Bookmark: [2 min](https://www.youtube.com/watch?v=0iHdJGbSUi4)

### Building and running

    lein deps
    lein uberjar
