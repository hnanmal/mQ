(ns snake-clojure.core-test
  (:require [clojure.test :refer :all]
            [snake-clojure.core :refer :all]))

(deftest a-test
  (testing "FIXME, I fail."
    (is (= 0 1))))
