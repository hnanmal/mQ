The following files are currently built from an Autodesk internal project and copied to this repo

* AdpSDKCSharpWrapper.dll
* Analytics.Net.ADP.dll
* Analytics.NET.Core.dll
* Analytics.NET.Google.dll